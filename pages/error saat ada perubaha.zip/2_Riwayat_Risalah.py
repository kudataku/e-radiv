import streamlit as st
import sqlite3

st.title("📚 Riwayat Risalah")

conn = sqlite3.connect('database/risalah.db')
cursor = conn.cursor()
cursor.execute("SELECT id, tanggal, agenda, pimpinan FROM risalah ORDER BY id DESC")
rows = cursor.fetchall()
conn.close()

if rows:
    for row in rows:
        with st.expander(f"📅 {row[1]} - {row[2]} (Pimpinan: {row[3]})"):
            conn = sqlite3.connect('database/risalah.db')
            cursor = conn.cursor()
            cursor.execute("SELECT transcript FROM risalah WHERE id = ?", (row[0],))
            data = cursor.fetchone()
            conn.close()

            st.write(data[0])
else:
    st.info("Belum ada risalah yang disimpan.")
